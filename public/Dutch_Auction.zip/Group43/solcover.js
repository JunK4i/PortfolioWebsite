module.exports = {
    skipFiles: ['attacker.sol'],
}