import json
import requests
import re
import time
import os
import csv

# Stage 1 filtering
# If 2.json already exist, omit this stage
if not os.path.exists("2.json"):
    print("2.json does not exist. Performing stage 1 filtering...")
    # Read data from "1.json", 1.json being the most original data
    with open("1.json", "r") as input_file:
        data = json.load(input_file)
    # Function to check if a date is within the specified range
    def is_within_range(date_str):
        start_date = "2023-01-01"
        end_date = "2023-08-31"
        return start_date <= date_str <= end_date
    # Filter the data based on the date range
    filtered_data = [entry for entry in data if is_within_range(entry["discovered"])]
    # Store the filtered data in a variable
    filtered_data_json = json.dumps(filtered_data, indent=4)

    # Make sure the data['group_name'] is from either lockbit3,clop, and alphv
    filtered_data = [entry for entry in filtered_data if entry["group_name"] in ["lockbit3", "clop", "alphv"]]
    # Store the filtered data in a variable
    filtered_data_json = json.dumps(filtered_data, indent=4)

    # TODO: Make sure the post_title doesn't exceed 40 characters, if not it is highly unlikely to be accurate (May contain irreleavent strings such as "DATA LEAKED BLABLABLA")

    # dump the filtered data into a 2.json
    with open("2.json", "w") as output_file:
        json.dump(filtered_data, output_file, indent=4)


# Load country-codes-tlds.json, {"country": "Afghanistan", "tlds": [".af"]}, extract the post_title(if it's a domain name), and match against the tlds
# If matched, add the country to a new key called "country" in the dictionary
# If not matched, add "Unknown" to the new key

# Load country-codes, for domain checks
with open("country-codes-tlds.json", "r") as input_file:
    country_tlds_data = json.load(input_file)

# print(country_tlds_data)

# def get_country_from_domain(domain):
#     # Use regular expression to extract TLD from domain 
#     match = re.search(r'\.([a-zA-Z]+)$', domain)    
#     if match:
#         tld = match.group(1)
#         # ignore those with .net .com .org
#         if tld in ["net", "com", "org","co","COM","NET","ORG","CO","EDU","edu","gov","GOV"]:
#             return "Unknown"
#         return tld
#     else:
#         return "Unable to determine TLD"

# If the domain contains suffix like .sg, assume it's singapore
# with open("2.json", "r") as input_file:
#     data = json.load(input_file)
#     for entry in data:
#         country = get_country_from_domain(entry["post_title"])
#         entry['country'] = country
#     # dump the filtered data into a 2.json
#     with open("2.json", "w") as output_file:
#         json.dump(data, output_file, indent=4)


# Using SIC Code to find out the industry of the company

# Load SIC_Code.csv into a dictionary
with open("SIC_Code.csv", "r") as input_file:
    # ignore the first line
    next(input_file)
    # header contains Division,Major Group,Description, I only want the Major Group and Description in the dictionary
    sic_code_data = {row[1]: row[2] for row in csv.reader(input_file)}

# print(sic_code_data)

url = "https://google.serper.dev/search"

# load 2.json, put post_title into the payload
with open("2.json", "r") as input_file:
    data = json.load(input_file)
    for entry in data:
        # if the data contains industry, skip
        if "industry" in entry:
            print(f"Industry checked liao,skipping {entry['post_title']}")
            continue
        payload = json.dumps({
            "q": f"{entry['post_title']} \"SIC\""
        })
        headers = {
            'X-API-KEY': '5124b6b9941d3d2bce3d76bbca15280341a419f6',
            # f410574a3c11f4c5028cc35a32d5e634f8a64bbf
            # 
            'Content-Type': 'application/json'
        }

        response = requests.request("POST", url, headers=headers, data=payload).json()
        # get organic results
        print(response)

        for result in response["organic"]:
            # SIC\D+(\d[\d,]+) matches SIC followed by a number
            match = re.search(r'SIC\D+(\d[\d,]+)', result["snippet"])
            if match:
                sic_code = match.group(1)
                print(sic_code)
                # remove the comma
                sic_code = sic_code.replace(",", "")
                # get the first 2 digits only
                sic_code = sic_code[:2]
                if sic_code in sic_code_data:
                    # TODO: Maybe can add a counter for confidence level
                    print(sic_code_data[sic_code])
                    # add the industry to the dictionary
                    entry["industry"] = sic_code_data[sic_code]
                    break
                else:
                    entry["industry"] = "Unknown"
                    print("SIC Code not found")
            else:
                entry["industry"] = "Unknown"
                print("SIC Code not found")
            # output the result to a 2.json
        with open("2.json", "w") as output_file:
            json.dump(data, output_file, indent=4)

# Open 2.json and check for the key country, if the country consist of 'Unable to determine TLD' or 'Unknown', then proceed, if not skip
with open("2.json", "r") as input_file:
    data = json.load(input_file)
    for entry in data:
        if 'country' in entry:
            print(f"Country for {entry} checked liao,skipping")
            continue

        payload = json.dumps({
            "q": f"{entry['post_title']} is from which country?",
            "gl": "sg"
        })
        headers = {'X-API-KEY': 'c5de4276307cc4dbee64050046bbb3b17cdc69e8','Content-Type': 'application/json'}
        # c5de4276307cc4dbee64050046bbb3b17cdc69e8
        # f410574a3c11f4c5028cc35a32d5e634f8a64bbf(old)
        response = requests.request("POST", url, headers=headers, data=payload).json()
        print(f"Checking {entry['post_title']}")
        
        # Answer box is more accurate.
        try:
            if "answerBox" in response:
                print(f"{entry['post_title']} Answerbox answer found!!")
                for country_name in country_tlds_data:
                    # if country_name['country'] in response["answerBox"]["answer"] or response["answerBox"]["answer"] in country_name['country']:
                    #     print(country_name['country'])
                    #     entry['country'] = country_name['country']
                    #     with open("2.json", "w") as output_file:
                    #         json.dump(data, output_file, indent=4)
                    if country_name['country'] in response["answerBox"]["snippet"] or response["answerBox"]["snippet"] in country_name['country']:
                        print(country_name['country'])
                        entry['country'] = country_name['country']
                        with open("2.json", "w") as output_file:
                            json.dump(data, output_file, indent=4)
                continue
        except Exception as e:
            print(e)
            pass
        
        answer_found = None
        counter = {}

        for result in response["organic"]:
            # if answer_found:
            #     print(f"{entry['post_title']} Answer found: {entry['country']}")
            #     break
            for country_name in country_tlds_data:
                if country_name['country'] in result["snippet"] or result["snippet"] in country_name['country']:
                    # answer_found = True
                    counter[country_name['country']] = counter.get(country_name['country'], 0) + 1
                    # print(country_name['country'])
        
        if counter:
            max_key = max(counter, key=counter.get)
            print(f"{counter}, {max_key} will be chosen as the highest confidence level in terms of country")
            entry['country'] = max_key
        else:
            entry['country'] = "Unknown"

        with open("2.json", "w") as output_file:
            json.dump(data, output_file, indent=4)
                
                    # the one with the highest count is the most accurate                            
                            # break
                    # entry['country'] = country_name['country']

                    # with open("2.json", "w") as output_file:
                    #     json.dump(data, output_file, indent=4)
                    # break


print("Modified data has been updated in '2.json'.")
